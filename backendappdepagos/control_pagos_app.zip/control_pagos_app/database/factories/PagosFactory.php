<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Pago;
use Faker\Generator as Faker;

$factory->define(Pago::class, function (Faker $faker) {
    return [
        'ruta_voucher' => $faker->url,
        'concepto' => $faker->sentence,
        'monto' => $faker->randomFloat(0, 0, 10000.),
        'op_fecha' => $faker->date(),
        'op_numero' => $faker->bankAccountNumber,
        'op_cuenta'=>$faker->bankAccountNumber,
        'op_banco' => $faker->name,
    ];
});
