<?php

use Illuminate\Database\Seeder;

class AlumnoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(\App\Alumno::class, 5)->create();

        factory(\App\Concepto::class, 5)->create();
    }
}
