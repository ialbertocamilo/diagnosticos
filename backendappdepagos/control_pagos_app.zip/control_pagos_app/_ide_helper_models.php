<?php

// @formatter:off
/**
 * A helper file for your Eloquent Models
 * Copy the phpDocs from this file to the correct Model,
 * And remove them from this file, to prevent double declarations.
 *
 * @author Barry vd. Heuvel <barryvdh@gmail.com>
 */


namespace App{
/**
 * App\Alumno
 *
 * @property int $id
 * @property string $nombre
 * @property string $telefono
 * @property string $celular
 * @property string $correo
 * @property int $user_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\User $user
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Alumno newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Alumno newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Alumno query()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Alumno whereCelular($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Alumno whereCorreo($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Alumno whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Alumno whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Alumno whereNombre($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Alumno whereTelefono($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Alumno whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Alumno whereUserId($value)
 */
	class Alumno extends \Eloquent {}
}

namespace App{
/**
 * App\Concepto
 *
 * @property int $id
 * @property string $nombre
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Pago[] $pagos
 * @property-read int|null $pagos_count
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Concepto newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Concepto newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Concepto query()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Concepto whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Concepto whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Concepto whereNombre($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Concepto whereUpdatedAt($value)
 */
	class Concepto extends \Eloquent {}
}

namespace App{
/**
 * App\Pago
 *
 * @property int $id
 * @property string $ruta_voucher
 * @property int $concepto_id
 * @property float $monto
 * @property string $op_fecha
 * @property string $op_numero
 * @property string $op_banco
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Concepto $conceptos
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago query()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereConceptoId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereMonto($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereOpBanco($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereOpFecha($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereOpNumero($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereRutaVoucher($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereUpdatedAt($value)
 */
	class Pago extends \Eloquent {}
}

namespace App{
/**
 * App\User
 *
 * @property int $id
 * @property string $name
 * @property string $email
 * @property \Illuminate\Support\Carbon|null $email_verified_at
 * @property string $password
 * @property string|null $remember_token
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Notifications\DatabaseNotificationCollection|\Illuminate\Notifications\DatabaseNotification[] $notifications
 * @property-read int|null $notifications_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Laravel\Sanctum\PersonalAccessToken[] $tokens
 * @property-read int|null $tokens_count
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User query()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereEmail($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereEmailVerifiedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User wherePassword($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereRememberToken($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereUpdatedAt($value)
 */
	class User extends \Eloquent {}
}

