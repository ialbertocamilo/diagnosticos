<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * App\Pago
 *
 * @property int $id
 * @property string $ruta_voucher
 * @property int $concepto_id
 * @property float $monto
 * @property string $op_fecha
 * @property string $op_numero
 * @property string|null $op_cuenta
 * @property string $op_banco
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago query()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereConceptoId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereMonto($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereOpBanco($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereOpCuenta($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereOpFecha($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereOpNumero($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereRutaVoucher($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereUpdatedAt($value)
 * @mixin \Eloquent
 * @property string|null $concepto
 * @property string|null $dni
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereConcepto($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Pago whereDni($value)
 */
class Pago extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $timestamps = true;
    protected $fillable = [
        'ruta_voucher',
        'concepto',
        'monto',
        'op_fecha',
        'op_numero',
        'op_banco',
        'dni',
        'nombres',
        'created_at'
    ];
    protected $hidden = [
        'updated_at',
    ];

//    protected $hidden = [
//        'op_fecha'
//    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */

    protected $casts = [
        'id' => 'integer',
        'monto' => 'float',
        'op_fecha' => 'date',
    ];



}
