<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property string $var
 * @property string $value
 * @property string $created_at
 * @property string $updated_at
 */
class Config extends Model
{
    public $timestamps = true;
    /**
     * @var array
     */
    protected $fillable = ['var', 'value'];

}
