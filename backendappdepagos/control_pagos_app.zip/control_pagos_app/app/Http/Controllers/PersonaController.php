<?php

namespace App\Http\Controllers;

use App\Pago;
use App\Persona;
use Illuminate\Http\Request;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use PhpOffice\PhpSpreadsheet\Writer\Exception;

class PersonaController extends Controller
{

    public function uploadPersonas(Request $request)
    {
//application/vnd.ms-excel

        $excel = new Xlsx();
        $spreadsheet = $excel->load($request->excel);
        $sheet = $spreadsheet->setActiveSheetIndex(0);
        $i = 2;
        while (true) {
            $nombre = $sheet->getCellByColumnAndRow(1, $i)->getFormattedValue();
            $dni = $sheet->getCellByColumnAndRow(2, $i)->getFormattedValue();

            if ($nombre != '' && $dni != '') {
                if (!Persona::where([
                    'dni' => $dni
                ])->first()) {
                    Persona::create([
                        'nombre' => $nombre,
                        'dni' => $dni
                    ]);
                }
                if ($pago = Pago::where([
                    'dni' => $dni
                ])->first()) {

                    $pago->nombres = $nombre;
                    $pago->save();
                }
            } else
                break;
            $i++;
        }

        $writter = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);

        $time = microtime();
        $time = str_replace(' ', '', $time);
        \Storage::disk('local')->makeDirectory('personas');
        $myfile = "{$time}_personas.xlsx";
        try {
            $writter->save(storage_path('app/personas/') . $myfile);
        } catch (Exception $e) {
            return response(['msg' => 'Ocurrio un error al subir el archivo'], 400);
        }
        return response(['msg' => 'Se ha subido correctamente'], 200);
    }

    public function list()
    {

        return response(Persona::getQuery()->paginate(15, ['id', 'nombre', 'dni']), 200);
    }
}
