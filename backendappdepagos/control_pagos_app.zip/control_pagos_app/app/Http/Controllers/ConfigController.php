<?php

namespace App\Http\Controllers;

use App\Config;
use Illuminate\Http\Request;

class ConfigController extends Controller
{

    public function getConfig(Request $request)
    {
        $var = $request->var;
        $val = Config::where([
            'var' => $var
        ])->first();

        return response($val, 200);
    }

    public function setConfig(Request $request)
    {

        $var = $request->var;
        $val = $request->val;
        $myconfig = Config::where([
            'var' => $var
        ])->first();
        if ($request->val) {
            $myconfig->value = $val;
            return response()->json($myconfig->save(), 200);
        }
        $myconfig->value = '';
        return response()->json($myconfig->save(), 200);
    }

    public function getAllConfig()
    {
        return response()->json(Config::all(), 200);
    }
}
