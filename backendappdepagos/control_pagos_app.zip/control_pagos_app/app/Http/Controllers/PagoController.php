<?php

namespace App\Http\Controllers;

use App\Http\Requests\PagoUpdateRequest;
use App\Http\Resources\Pago as PagoResource;
use App\Http\Resources\PagoCollection;
use App\Pago;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Exception;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class PagoController extends Controller
{

    private $allresult;

    /**
     * @param \Illuminate\Http\Request $request
     * @return \App\Http\Resources\PagoCollection
     */
    public function index(Request $request)
    {
        $pagos = Pago::paginate(15);

        return new PagoCollection($pagos);
    }

    /**
     * @param \App\Http\Requests\PagoStoreRequest $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\Routing\ResponseFactory|\Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $data = $request->only('dni', 'concepto', 'monto', 'op_fecha', 'op_numero', 'op_cuenta', 'op_banco');

        if (Pago::where(['op_numero' => $data['op_numero']])->first()) {
            return \response('error numero de operacion registrado', 422);
        }

        $voucher = $request->file('ruta_voucher');
        $filename = $voucher->store('vouchers');
        $data = $data + array('ruta_voucher' => $filename);
        $pago = Pago::create(
            $data
        );

        return \response()->json(['msg' => 'La operación se realizó con éxito'], 200);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param \App\pago $pago
     * @return \App\Http\Resources\Pago
     */
    public function show(Request $request, Pago $pago)
    {
        return new PagoResource($pago);
    }

    /**
     * @param \App\Http\Requests\PagoUpdateRequest $request
     * @param \App\pago $pago
     * @return \App\Http\Resources\Pago
     */
    public function update(PagoUpdateRequest $request, Pago $pago)
    {
        $pago->update([]);

        return new PagoResource($pago);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param \App\pago $pago
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, Pago $pago)
    {
        $pago->delete();

        return response()->noContent(200);
    }


    public function getlistapago(Request $request)
    {


        if (isset($request->op_fecha_from) && isset($request->op_fecha_to)) {

            $res = Pago::where(
                [
                    ['concepto', 'like', "%$request->concepto%"],
                    ['monto', 'like', "%$request->monto%"],
                    ['op_numero', 'like', "%$request->op_numero%"],
                    ['op_banco', 'like', "%$request->op_banco%"],
                    ['dni', 'like', "%$request->dni%"],
                    ['nombres', 'like', "%$request->nombres%"],
                ]
//                ['created_at', 'like', "%$request->created_at%"],
            )->whereBetween('op_fecha', [$request->op_fecha_from, $request->op_fecha_to]);
        } else {
            $res = Pago::where(
                [
                    ['concepto', 'like', "%$request->concepto%"],
                    ['monto', 'like', "%$request->monto%"],
                    ['op_fecha', 'like', "%$request->op_fecha%"],
                    ['op_numero', 'like', "%$request->op_numero%"],
                    ['op_banco', 'like', "%$request->op_banco%"],
//                    ['created_at', 'like', "%$request->created_at%"],
                    ['dni', 'like', "%$request->dni%"],
                    ['nombres', 'like', "%$request->nombres%"],
                ]
            );

        }
//        return response($res, 200);
//        return response($res, 200);
        $res = $res->paginate(15);
        $res = new PagoCollection($res);
        return response($res, 200);

    }

    public function downloadExcel(Request $request)
    {
        $query = Pago::where(
            [
                ['concepto', 'like', "%$request->concepto%"],
                ['monto', 'like', "%$request->monto%"],
                ['op_fecha', 'like', "%$request->op_fecha%"],
                ['op_numero', 'like', "%$request->op_numero%"],
                ['op_banco', 'like', "%$request->op_banco%"],
                ['created_at', 'like', "%$request->created_at%"],
                ['dni', 'like', "%$request->dni%"]
            ]
        )->get();


        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->setActiveSheetIndex(0);

        $sheet->getRowDimension('1')->setRowHeight(50);
        $sheet->getRowDimension('2')->setRowHeight(20);
        $spreadsheet->getActiveSheet()->getColumnDimension('A')->setWidth(10);
        $spreadsheet->getActiveSheet()->getColumnDimension('B')->setWidth(10);
        $spreadsheet->getActiveSheet()->getColumnDimension('C')->setWidth(50);
        $spreadsheet->getActiveSheet()->getColumnDimension('D')->setWidth(50);
        $spreadsheet->getActiveSheet()->getColumnDimension('E')->setWidth(25);
        $spreadsheet->getActiveSheet()->getColumnDimension('F')->setWidth(10);
        $spreadsheet->getActiveSheet()->getColumnDimension('G')->setWidth(50);
        $spreadsheet->getActiveSheet()->getColumnDimension('H')->setWidth(25);
        $spreadsheet->getActiveSheet()->getColumnDimension('I')->setWidth(25);
        $sheet->setCellValue('A1', 'N°');
        $sheet->setCellValue('B1', 'DNI');
        $sheet->setCellValue('C1', 'Nombre');
        $sheet->setCellValue('D1', 'Concepto');
        $sheet->setCellValue('E1', 'Banco');
        $sheet->setCellValue('F1', 'Monto');
        $sheet->setCellValue('G1', 'Nro. Operacion');
        $sheet->setCellValue('H1', 'Fecha de operacion bancaria');
        $sheet->setCellValue('I1', 'Fecha generacion');

        $index = 2;
        foreach ($query as $data) {
            $sheet->setCellValue("A{$index}", $index - 1);
            $sheet->setCellValue("B{$index}", " " . $data->dni);
            $sheet->setCellValue("C{$index}", " " . $data->nombres);
            $sheet->setCellValue("D{$index}", " " . $data->concepto);
            $sheet->setCellValue("E{$index}", " " . $data->op_banco);
            $sheet->setCellValue("F{$index}", "" . $data->monto);
            $sheet->setCellValue("G{$index}", " " . $data->op_numero);
            $sheet->setCellValue("H{$index}", "" . $data->op_fecha);
            $sheet->setCellValue("I{$index}", "" . $data->created_at);
            $index++;
        }


        $writer = new Xlsx($spreadsheet);
        try {
            $writer->save(storage_path('app/vouchers') . "/reporte.xlsx");
            $headers = array('Content-Type : application/vnd.ms-excel; charset=utf-8');
            return Storage::download('vouchers/reporte.xlsx', 'excel.xlsx', $headers);
        } catch (Exception $e) {
            return response('error', 400);
        }
        return response('error', 400);

//        $hoja = new Spreadsheet();
//        $excel = new Xlsx($hoja);
//        $excel->save('excel');
    }

    public function getImageById(Request $request)
    {
        $res = Pago::findOrFail($request->id);

        return Storage::response($res->ruta_voucher);
    }

}
