<?php

namespace App\Http\Controllers;

use App\Alumno;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{


    public function login(Request $request)
    {
        $data = [];
        if (Auth::attempt($request->all())) {
            $token = Auth::user()->createToken('userToken')->plainTextToken;
            $data = ['code' => 204, 'token' => $token, 'user' => Auth::user()];
        } else
            $data = ['code' => 402, 'user' => Auth::user()];


        return response()->json($data);

    }

    public function register(Request $request)

    {
        $user = new User();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->id;
        if ($user->save()) {
            return response(['msg'=>'success'], 201);//->json($resp, 201);
        }
        return response(['error' => 'No se pudo registrar'], 401);
    }

    public function logout(Request $request)
    {
//            $request->user()->tokens()->delete();
            Auth::logout();
            return response('done', 200);

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $user = User::all();
        return response()->json($user);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
