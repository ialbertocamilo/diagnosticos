<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PagoStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'dni'=>'required',
            'ruta_boucher' => 'required',
            'concepto'=> 'required',
            'monto'=> 'required',
            'op_fecha'=> 'required',
            'op_numero'=> 'required',
            'op_cuenta'=> 'required',
            'op_banco'=> 'required',

        ];
    }
}
