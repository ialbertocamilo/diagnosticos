<?php


namespace App\Http\Resources;


use Illuminate\Http\Resources\Json\JsonResource;

class Pago extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'ruta_voucher' => $this->ruta_voucher,
            'concepto' => $this->concepto,
            'monto' => $this->monto,
            'op_fecha' => $this->op_fecha->format('d-m-Y'),
            'op_numero' => $this->op_numero,
            'op_cuenta' => $this->op_cuenta,
            'op_banco' => $this->op_banco,
            'created_at' => $this->created_at->format('d-m-Y'),
            'dni' => $this->dni,
            'nombres'=>$this->nombres
            ];
    }
}
