<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property string $nombre
 * @property string $dni
 * @property string $telefono
 * @property string $celular
 * @property string $created_at
 * @property string $updated_at
 */
class Persona extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['nombre', 'dni', 'telefono', 'celular', 'created_at', 'updated_at'];

}
