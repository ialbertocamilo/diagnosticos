<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});


Route::get('/personas', 'PersonaController@list')->middleware('auth:sanctum');
Route::post('/subir', 'PersonaController@uploadPersonas')->middleware('auth:sanctum');
Route::post('/excel', 'PagoController@downloadExcel')->middleware('auth:sanctum');
Route::post('/getlistapago', 'PagoController@getlistapago')->middleware('auth:sanctum');
Route::post('/set-config', 'ConfigController@setConfig')->middleware('auth:sanctum');
Route::post('/get-config', 'ConfigController@getConfig')->middleware('auth:sanctum');
Route::get('/get-all-config', 'ConfigController@getAllConfig')->middleware('auth:sanctum');
Route::post('/get-voucher', 'PagoController@getImageById')->middleware('auth:sanctum');
Route::post('/pago', 'PagoController@store');
Route::post('/login', 'UserController@login');
Route::post('/register', 'UserController@register');
Route::post('/logout', 'UserController@logout');
