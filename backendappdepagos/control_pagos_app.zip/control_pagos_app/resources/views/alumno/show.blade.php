@extends('layouts.app')

@section('content')
    alumno.show template
@endsection