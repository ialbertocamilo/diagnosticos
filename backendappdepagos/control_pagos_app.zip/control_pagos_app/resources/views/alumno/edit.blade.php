@extends('layouts.app')

@section('content')
    alumno.edit template
@endsection