@extends('layouts.app')

@section('content')
    alumno.index template
@endsection