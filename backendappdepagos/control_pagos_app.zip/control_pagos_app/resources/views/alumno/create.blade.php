@extends('layouts.app')

@section('content')
    alumno.create template
@endsection