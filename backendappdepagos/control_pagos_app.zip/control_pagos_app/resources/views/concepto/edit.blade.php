@extends('layouts.app')

@section('content')
    concepto.edit template
@endsection