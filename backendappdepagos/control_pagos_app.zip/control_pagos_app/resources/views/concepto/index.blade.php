@extends('layouts.app')

@section('content')
    concepto.index template
@endsection