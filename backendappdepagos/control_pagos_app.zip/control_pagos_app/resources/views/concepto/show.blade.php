@extends('layouts.app')

@section('content')
    concepto.show template
@endsection