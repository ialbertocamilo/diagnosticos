@extends('layouts.app')

@section('content')
    concepto.create template
@endsection