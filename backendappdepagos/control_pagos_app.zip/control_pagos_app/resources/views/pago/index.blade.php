@extends('layouts.app')

@section('content')
    pago.index template
@endsection