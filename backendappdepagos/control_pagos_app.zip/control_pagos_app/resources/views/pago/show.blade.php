@extends('layouts.app')

@section('content')
    pago.show template
@endsection