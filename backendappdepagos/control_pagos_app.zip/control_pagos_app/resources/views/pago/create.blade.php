@extends('layouts.app')

@section('content')
    pago.create template
@endsection