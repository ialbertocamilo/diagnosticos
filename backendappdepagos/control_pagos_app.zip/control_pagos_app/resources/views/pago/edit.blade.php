@extends('layouts.app')

@section('content')
    pago.edit template
@endsection