<?php

namespace Tests\Feature\Http\Controllers;

use App\Alumno;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use JMac\Testing\Traits\AdditionalAssertions;
use Tests\TestCase;

/**
 * @see \App\Http\Controllers\AlumnoController
 */
class AlumnoControllerTest extends TestCase
{
    use AdditionalAssertions, RefreshDatabase, WithFaker;

    /**
     * @test
     */
    public function index_displays_view()
    {
        $alumnos = factory(Alumno::class, 3)->create();

        $response = $this->get(route('alumno.index'));

        $response->assertOk();
        $response->assertViewIs('alumno.index');
        $response->assertViewHas('alumnos');
    }


    /**
     * @test
     */
    public function create_displays_view()
    {
        $response = $this->get(route('alumno.create'));

        $response->assertOk();
        $response->assertViewIs('alumno.create');
    }


    /**
     * @test
     */
    public function store_uses_form_request_validation()
    {
        $this->assertActionUsesFormRequest(
            \App\Http\Controllers\AlumnoController::class,
            'store',
            \App\Http\Requests\AlumnoStoreRequest::class
        );
    }

    /**
     * @test
     */
    public function store_saves_and_redirects()
    {
        $alumno = $this->faker->word;

        $response = $this->post(route('alumno.store'), [
            'alumno' => $alumno,
        ]);

        $alumnos = Alumno::query()
            ->where('alumno', $alumno)
            ->get();
        $this->assertCount(1, $alumnos);
        $alumno = $alumnos->first();

        $response->assertRedirect(route('alumno.index'));
        $response->assertSessionHas('alumno.id', $alumno->id);
    }


    /**
     * @test
     */
    public function show_displays_view()
    {
        $alumno = factory(Alumno::class)->create();

        $response = $this->get(route('alumno.show', $alumno));

        $response->assertOk();
        $response->assertViewIs('alumno.show');
        $response->assertViewHas('alumno');
    }


    /**
     * @test
     */
    public function edit_displays_view()
    {
        $alumno = factory(Alumno::class)->create();

        $response = $this->get(route('alumno.edit', $alumno));

        $response->assertOk();
        $response->assertViewIs('alumno.edit');
        $response->assertViewHas('alumno');
    }


    /**
     * @test
     */
    public function update_uses_form_request_validation()
    {
        $this->assertActionUsesFormRequest(
            \App\Http\Controllers\AlumnoController::class,
            'update',
            \App\Http\Requests\AlumnoUpdateRequest::class
        );
    }

    /**
     * @test
     */
    public function update_redirects()
    {
        $alumno = factory(Alumno::class)->create();
        $alumno = $this->faker->word;

        $response = $this->put(route('alumno.update', $alumno), [
            'alumno' => $alumno,
        ]);

        $response->assertRedirect(route('alumno.index'));
        $response->assertSessionHas('alumno.id', $alumno->id);
    }


    /**
     * @test
     */
    public function destroy_deletes_and_redirects()
    {
        $alumno = factory(Alumno::class)->create();

        $response = $this->delete(route('alumno.destroy', $alumno));

        $response->assertRedirect(route('alumno.index'));

        $this->assertDeleted($alumno);
    }
}
