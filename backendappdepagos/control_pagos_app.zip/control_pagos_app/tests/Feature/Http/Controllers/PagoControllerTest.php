<?php

namespace Tests\Feature\Http\Controllers;

use App\Pago;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use JMac\Testing\Traits\AdditionalAssertions;
use Tests\TestCase;

/**
 * @see \App\Http\Controllers\PagoController
 */
class PagoControllerTest extends TestCase
{
    use AdditionalAssertions, RefreshDatabase, WithFaker;

    /**
     * @test
     */
    public function index_behaves_as_expected()
    {
        $pagos = factory(Pago::class, 3)->create();

        $response = $this->get(route('pago.index'));
    }


    /**
     * @test
     */
    public function store_uses_form_request_validation()
    {
        $this->assertActionUsesFormRequest(
            \App\Http\Controllers\PagoController::class,
            'store',
            \App\Http\Requests\PagoStoreRequest::class
        );
    }

    /**
     * @test
     */
    public function store_saves()
    {
        $pago = $this->faker->word;

        $response = $this->post(route('pago.store'), [
            'pago' => $pago,
        ]);

        $pagos = Pago::query()
            ->where('pago', $pago)
            ->get();
        $this->assertCount(1, $pagos);
        $pago = $pagos->first();
    }


    /**
     * @test
     */
    public function show_behaves_as_expected()
    {
        $pago = factory(Pago::class)->create();

        $response = $this->get(route('pago.show', $pago));
    }


    /**
     * @test
     */
    public function update_uses_form_request_validation()
    {
        $this->assertActionUsesFormRequest(
            \App\Http\Controllers\PagoController::class,
            'update',
            \App\Http\Requests\PagoUpdateRequest::class
        );
    }

    /**
     * @test
     */
    public function update_behaves_as_expected()
    {
        $pago = factory(Pago::class)->create();
        $pago = $this->faker->word;

        $response = $this->put(route('pago.update', $pago), [
            'pago' => $pago,
        ]);
    }


    /**
     * @test
     */
    public function destroy_deletes_and_responds_with()
    {
        $pago = factory(Pago::class)->create();

        $response = $this->delete(route('pago.destroy', $pago));

        $response->assertOk();

        $this->assertDeleted($pago);
    }
}
